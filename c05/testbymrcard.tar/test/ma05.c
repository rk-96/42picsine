/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma05.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/29 04:52:34 by schaisil          #+#    #+#             */
/*   Updated: 2022/01/29 05:32:49 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_sqrt(int nb);

int	main(void)
{
	int	result;

	for (int i = 0; i < 10; i++)
	{
		result = ft_sqrt(i);
		printf("nb: %d, return: %d\n", i, result);
	}
	printf("nb: %d, return: %d\n", 2147395600, ft_sqrt(2147395600));
	printf("nb: %d, return: %d\n", -16, ft_sqrt(-16));
	return (0);
}
