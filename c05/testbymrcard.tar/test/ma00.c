/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma00.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/28 04:56:59 by schaisil          #+#    #+#             */
/*   Updated: 2022/01/28 05:17:03 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_iterative_factorial(int nb);

int	main(void)
{
	for (int i = -1; i < 15; i++)
		printf("%d!: %d\n",i, ft_iterative_factorial(i));
	return (0);
}
