norminette -R CheckForbiddenSourceHeader ../ex00/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex01/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex02/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex03/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex04/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex05/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex06/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex07/ft*.c \
&& norminette -R CheckForbiddenSourceHeader ../ex08/ft*.c
