/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma01.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/28 05:23:48 by schaisil          #+#    #+#             */
/*   Updated: 2022/01/28 05:25:36 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_recursive_factorial(int nb);

int	main(void)
{
	for (int i = -1; i < 15; i++)
		printf("%d!: %d\n", i, ft_recursive_factorial(i));
	return (0);
}
