mv ../ex00/ma00.c . \
&& mv ../ex01/ma01.c . \
&& mv ../ex02/ma02.c . \
&& mv ../ex03/ma03.c . \
&& mv ../ex04/ma04.c . \
&& mv ../ex05/ma05.c . \
&& mv ../ex06/ma06.c . \
&& mv ../ex07/ma07.c .
