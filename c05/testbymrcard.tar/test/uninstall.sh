rm ../ex00/ma00.c \
&& rm ../ex01/ma01.c \
&& rm ../ex02/ma02.c \
&& rm ../ex03/ma03.c \
&& rm ../ex04/ma04.c \
&& rm ../ex05/ma05.c \
&& rm ../ex06/ma06.c \
&& rm ../ex07/ma07.c
