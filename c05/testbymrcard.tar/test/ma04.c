/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma04.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/29 04:27:22 by schaisil          #+#    #+#             */
/*   Updated: 2022/01/29 04:36:03 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_fibonacci(int index);

int	main(void)
{
	for (int i = -2; i < 10; i++)
		printf("index: %d, return %d\n", i, ft_fibonacci(i));

	for (int i = 45; i < 48; i++)
		printf("index: %d, return %d\n", i, ft_fibonacci(i));
	return (0);
}
