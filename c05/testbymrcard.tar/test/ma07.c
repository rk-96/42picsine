/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma07.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/29 10:21:36 by schaisil          #+#    #+#             */
/*   Updated: 2022/02/03 10:29:22 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_find_next_prime(int nb);
int	ft_is_prime(int nb);

int	main(void)
{
	for (int i = -2; i < 10; i++)
		printf("nb: %d (%d), return: %d\n", i,
			       	ft_is_prime(i), ft_find_next_prime(i));
	printf("nb: %d (%d), return: %d\n",2147483626, ft_is_prime(2147483626),
		       	ft_find_next_prime(2147483626));
	printf("nb: %d (%d), return: %d\n",2147483632, ft_is_prime(2147483632),
		       	ft_find_next_prime(2147483632));
	printf("nb: %d (%d), return: %d\n",2147483647, ft_is_prime(2147483647),
		       	ft_find_next_prime(2147483647));
	return (0);
}
