cp ma00.c ../ex00 \
&& cp ma01.c ../ex01 \
&& cp ma02.c ../ex02 \
&& cp ma03.c ../ex03 \
&& cp ma04.c ../ex04 \
&& cp ma05.c ../ex05 \
&& cp ma06.c ../ex06 \
&& cp ma07.c ../ex07
