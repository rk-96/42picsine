/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma06.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/29 09:35:49 by schaisil          #+#    #+#             */
/*   Updated: 2022/02/03 10:22:26 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_is_prime(int nb);

int	main(void)
{
	for (int i = -2; i < 10; i++)
		printf("nb: %d, return: %d\n", i, ft_is_prime(i));
	
	for (int i = 2147483627; i < 2147483647; i++)
		printf("nb: %d, return: %d\n", i, ft_is_prime(i));

	printf("nb: %d, return: %d\n",2147483647, ft_is_prime(2147483647));

	return (0);
}
