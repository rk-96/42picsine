/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma02.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schaisil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/28 07:45:27 by schaisil          #+#    #+#             */
/*   Updated: 2022/01/28 10:29:31 by schaisil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_iterative_power(int nb, int power);

int	main(void)
{
	printf("nb: %d, power: %d, return: %d\n", 0, 0, ft_iterative_power(0, 0));
	printf("----------------------\n");			
	for (int i = -2; i < -1; i++)
	{
		printf("nb: %d, power: %d, return: %d\n", -4, i, ft_iterative_power(-4, i));
		printf("nb: %d, power: %d, return: %d\n", 0, i, ft_iterative_power(0, i));
		printf("nb: %d, power: %d, return: %d\n", 2, i, ft_iterative_power(2, i));
	}
	printf("----------------------\n");			
	printf("nb: %d, power: %d, return: %d\n", -2, 0, ft_iterative_power(-2, 0));
	printf("nb: %d, power: %d, return: %d\n", 4, 0, ft_iterative_power(4, 0));
	printf("----------------------\n");			
	for (int i = -2; i < 3; i++)
		printf("nb: %d, power: %d, return: %d\n", i, 3, ft_iterative_power(i, 3));
	printf("----------------------\n");			
	printf("nb: %d, power: %d, return: %d\n", 10, 9, ft_iterative_power(10, 9));
	printf("nb: %d, power: %d, return: %d\n", 10, 10, ft_iterative_power(10, 10));
	return (0);
}
